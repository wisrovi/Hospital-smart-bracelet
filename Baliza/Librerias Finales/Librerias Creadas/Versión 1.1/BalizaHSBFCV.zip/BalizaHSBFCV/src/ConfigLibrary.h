#ifndef Config_library_balizahsb
#define Config_library_balizahsb



#define number_rows 40
#define number_columns 20
#define cantidad_muestras_rssi 5
#define intervalodifrssi 5
#define max_registers_no_used 10




#endif