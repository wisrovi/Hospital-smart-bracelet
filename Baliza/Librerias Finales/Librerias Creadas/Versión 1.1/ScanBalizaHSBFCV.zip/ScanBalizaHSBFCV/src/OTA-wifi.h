#include <Update.h>

String getHeaderValue(String header, String headerName)
{
    String cabeza = header.substring(strlen(headerName.c_str()));
    return cabeza;
}

void OTA_extended_WIFI(String server_ota, String fileBinay_ota, int port_ota)
{
    delay(250);

    WiFiClient client_ota_update;
    { //start conection
        if (!client_ota_update.connect(server_ota.c_str(), port_ota))
        {
            Serial.println("connection failed");
            return;
        }

        Serial.println("Conectado");
    }

    Serial.println("Fetching Bin: " + String(fileBinay_ota));

    { // solicitamos leer el contenido del binario
        client_ota_update.print(String("GET ") + fileBinay_ota + " HTTP/1.1\r\n" +
                                "Host: " + server_ota + "\r\n" +
                                "Cache-Control: no-cache\r\n" +
                                "Connection: close\r\n\r\n");
    }

    const int time_limit = 5000;
    { //ponemos un timeout para evitar que se quede descargando eternamente
        unsigned long timeout = millis();
        while (client_ota_update.available() == 0)
        {
            if (millis() - timeout > time_limit)
            {
                Serial.println("client_ota_update Timeout !");
                client_ota_update.stop();
                return;
            }
        }
    }

    long contentLength = 0;
    bool isValidContentType = false;
    while (client_ota_update.available())
    {
        String line = client_ota_update.readStringUntil('\n');
        line.trim();
        if (!line.length())
        {
            break; //si la linea esta vacia, detengo la lectura de la respuesta
        }

        { //valido que el archivo exista, sino existe detengo la lectura
            if (line.startsWith("HTTP/1.1"))
            {
                if (line.indexOf("200") < 0)
                {
                    Serial.println("Server said: file not exist");
                    break;
                }
            }
        }

        { //hallo el tamaño del archivo a descargar
            if (line.startsWith("Content-Length: "))
            {
                contentLength = atol((getHeaderValue(line, "Content-Length: ")).c_str());
                Serial.println("Size File: " + String(contentLength) + ".");
            }
        }

        { //confirmo que el binario sea de tipo binario
            if (line.startsWith("Content-Type: "))
            {
                String contentType = getHeaderValue(line, "Content-Type: ");
                if (contentType == "application/octet-stream")
                {
                    isValidContentType = true;
                }
                else
                {
                    Serial.println("Got " + contentType + " payload.");
                }
            }
        }
    }

    if (contentLength && isValidContentType)
    {
        bool canBegin = Update.begin(contentLength); //confirmo que el archivo pueda ser guardado en la particion del OTA, de acuerdo a su tamaño
        if (canBegin)
        {
            Serial.println("Begin OTA. Patience! (please wait 2-5 minutes to finish).");

            { //descargo al archivo en la particion OTA, bit a bit, puede demorar hasta 5 minutos
                size_t written = Update.writeStream(client_ota_update);

                size_t size_binary_save = (written / contentLength) * 100;

                if (written != contentLength)
                {
                    Serial.println("save : " + String(size_binary_save) + " successfully");
                }
                else
                {
                    Serial.println("Completing download!!");
                }
            }

            { //si la descarga del archivo fue correcta, un daemon verfica el archivo que no tenga errores
                if (Update.end())
                {
                    Serial.println("OTA done!");
                    if (Update.isFinished()) //un daemon busca que no haya errores en el archivo
                    {                        // sin errores, sobreescribo el codigo con el archivo descargado y reinicio
                        Serial.println("Update successfully completed. Rebooting.");
                        delay(250);
                        ESP.restart();
                    }
                    else
                    { //el daemon encontro un error en la validacion del archivo
                        Serial.println("Update not finished!!");
                    }
                }
            }
        }
        else
        {
            Serial.println("En la particion para el OTA no cabe el archivo.");
            client_ota_update.flush();
        }
    }

    { //finished
        Serial.println();
        Serial.println("************************************");
        Serial.println("*     AWS OTA update finished      *");
        Serial.println("************************************");
        Serial.println();
    }
}