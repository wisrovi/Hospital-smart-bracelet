#include "ScanBalizaHSBFCV.h"
#include "AsyncElegantOTA.h"

#include "OTA-wifi.h"

#include <Preferences.h>
Preferences preferences;

String _mensajeEnviarBaliza = "prueba";
String dato1 = "";
String mensajeEnviar64 = "";
int cuentareset = 0;

AsyncWebServer server(80);

//Producción Paul
#define server_url "http://190.131.247.226:5000"
#define route_server "/hospitalsmartbracelet/received/"

//Pruebas Cesar
//#define server_url  "http://172.16.66.78:8080"
//#define route_server  "/esp32"

//Pruebas Cesar Home
//#define server_url  "http://192.168.1.57:8080"
//#define route_server  "/esp32"

//Pruebas William
//#define server_url "http://172.16.66.84:8000"
//#define route_server "/hospitalsmartbracelet/received/"

#define name_file_preferences "datBaliza"
#define name_key_ota_extended "OTA"

void ScanBalizaHSBFCV::enviarMensajePostBaliza()
{
  if (WiFi.status() == WL_CONNECTED)
  {                  //Check WiFi connection status
    HTTPClient http; //Declare object of class HTTPClient
    String url = server_url;
    url.concat(route_server);
    http.begin(url); //Specify request destination
    mensajeEnviar64 = base64::encode(_mensajeEnviarBaliza);
    //Serial.print("Datos libreria B");
    //Serial.println(_mensajeEnviarBaliza);
    mensajeEnviar64.replace('=', '*');
    //Serial.print("<");
    //Serial.print(mensajeEnviar64);
    //Serial.println(">");

    http.addHeader("Content-Type", "application/x-www-form-urlencoded");
    String packsend = "{\"key\":\"ESP32\",\"string_pack\":\"" + mensajeEnviar64 + "\"}";
    Serial.println(packsend);
    int httpCodeBaliza = http.POST(packsend); //Send the request
    String payloadBaliza = http.getString();
    Serial.print("httpCode: ");
    Serial.println(httpCodeBaliza); //Print HTTP return code
    Serial.print("payload: ");
    Serial.println(payloadBaliza); //Print request response payload
    http.end();
  }
  else
  {
    Serial.println("Error in WiFi connection");
  }
}

void ScanBalizaHSBFCV::InitSystemBaliza()
{
  preferences.begin(name_file_preferences, false);
  bool update_ota_now = preferences.getBool(name_key_ota_extended);
  preferences.end();

  WiFiManager wifiManager;
  wifiManager.setConfigPortalTimeout(120);
  if(!wifiManager.autoConnect("Baliza"))
  {
    Serial.println("Fallo al conectarse a lared, Se reiniciara..");
    ESP.restart();
  }
  

  if (update_ota_now)
  {
    preferences.begin(name_file_preferences, false);
    preferences.putBool(name_key_ota_extended, false);
    preferences.end();
    OTA_extended_WIFI("www.fcv.org", "/archivo/baliza/ota/baliza.ino.esp32.bin", 80);
  }
  else
  {
    AsyncElegantOTA.begin(&server); // Start ElegantOTA

    server.on("/OTA", HTTP_GET, [](AsyncWebServerRequest *request) {
      preferences.begin(name_file_preferences, false);
      preferences.putBool(name_key_ota_extended, true);
      preferences.end();
      request->send(200, "text/plain", "Enable OTA.");

      ESP.restart();
    });

    server.begin();    
  }
}

void ScanBalizaHSBFCV::OTABaliza()
{
  AsyncElegantOTA.loop();
}

void ScanBalizaHSBFCV::setMensajeBaliza(String _datobaliza)
{
  _mensajeEnviarBaliza = _datobaliza;
}

void ScanBalizaHSBFCV::ResetESP32()
{

  if (dato1 == _mensajeEnviarBaliza)
  {
    cuentareset++;
    if (cuentareset == 4)
    {
      Serial.println("Reset Baliza");
      ESP.restart();
      cuentareset = 0;
    }
  }
  else
  {
    dato1 = _mensajeEnviarBaliza;
    cuentareset = 0;
  }
}
