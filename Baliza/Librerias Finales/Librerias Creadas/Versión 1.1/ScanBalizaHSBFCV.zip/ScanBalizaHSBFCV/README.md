<!-- START COMPATIBILITY TABLE -->

## Compatibility

MCU         |Tested Works|Doesn't Work|Not Tested|Notes
------------|:----------:|:----------:|:--------:|-----
ESP32s		|      X     |            |          |


  * ESP32s 

<!-- END COMPATIBILITY TABLE -->