#ifndef baliza_hsb_fcv_library
#define baliza_hsb_fcv_library

#include "BalizaHSBFCV.h"
#include "Arduino.h"

#include "ConfigLibrary.h"

#define HM10 Serial2
char disi_result[5000];

bool thisScan[number_columns];
bool estadoused[number_rows];
String braceletmac[number_rows];
int braceletrssi[number_rows][number_columns];
int promediorssi = 0;
int promediototal = 0;
int countvalpro = 0;

int d1 = 0;
int i = 0;

String sedeBeacon = "";
String macBeacon1 = "";
String ppmBeacon = "";
String rssiBeacon = "";
String proximidadBeacon = "";
String caidaBeacon = "";
String temperaturaBeacon = "";
String voltajeBateria = "";
String totalbeacons = "";
String macBaliza = "";
String macb = "";
String macESP32 = "";

//****************************
//Detecta HM10
//****************************

void BalizaHSBFCV::start_at()
{
  Serial.begin(9600);
  Serial2.begin(9600);
  String c = "";

  do
  {
    HM10.print("AT");
    delay(500);
    if (HM10.available())
    {
      while (HM10.available())
      {
        c.concat(char(HM10.read()));
      }
    }
  } while (c != "OK");
  Serial.println("");
  Serial.println("Detección HM10 completa");

  if (c.equals("OK"))
  {
    HM10.print("AT+ADDR?");
    delay(500);
    if (HM10.available())
    {
      while (HM10.available())
      {
        char mac = HM10.read();
        macb.concat(String(mac)); // save the data in string format
        delay(1);
      }
    }
  }
  macBaliza = macb.substring(8);
  macESP32 = WiFi.macAddress();
  macESP32.remove(2, 1);
  macESP32.remove(4, 1);
  macESP32.remove(6, 1);
  macESP32.remove(8, 1);
  macESP32.remove(10, 1);
  Serial.print("La mac del ESP32 es: ");
  Serial.println(macESP32);

  Serial.print("La mac del HM10 es: ");
  Serial.println(macBaliza);
}

//*****************************************
//Imprime los datos recibidos
//****************************************

DynamicJsonDocument ProcesarDatos(String sedeBeacon, String voltajeBateria, String ppmBeacon, String proximidadBeacon, String caidaBeacon, String temperaturaBeacon, String rssiBeacon, String macBeacon)
{
  DynamicJsonDocument ibeacon(200);
  ibeacon["SED"] = sedeBeacon;
  ibeacon["MAC"] = macBeacon;
  ibeacon["BAT"] = voltajeBateria;
  ibeacon["PPM"] = ppmBeacon;
  ibeacon["CAI"] = caidaBeacon;
  ibeacon["TEM"] = temperaturaBeacon;
  ibeacon["RSI"] = rssiBeacon;
  ibeacon["PRO"] = proximidadBeacon;
  return ibeacon;
}

//*********************************
//Escanea sensores y clasifica la información para ser enviada
//*********************************

int BalizaHSBFCV::find_id_bracelet(String mac_search)
{
  bool findbrac = false;
  int respuesta = -1;
  for (int i = 0; i < number_rows; i++)
  {
    String newbracelet = braceletmac[i];

    if (newbracelet == mac_search)
    {
      respuesta = i;
      findbrac = true;
      break;
    }
  }

  if (findbrac == false)
  {
    for (int i = 1; i < number_rows; i++)
    {
      if (estadoused[i] == false)
      {
        braceletmac[i] = mac_search;
        for (int j = 0; j < number_columns; j++)
        {
          braceletrssi[i][j] = 0;
        }
        //Serial.print("Se registro la manilla con id: ");
        //Serial.println(i);
        estadoused[i] = true;
        respuesta = i;
        break;
      }
    }
  }

  return respuesta;
}

void BalizaHSBFCV::RegisterNewData(int id, int data)
{
  for (int i = number_columns - 1; i >= 1; i--)
  {
    braceletrssi[id][i + 1] = braceletrssi[id][i];
  }

  if (braceletrssi[id][2] != 0 && data != 0 && braceletrssi[id][3] != 0)
  {
    for (int i = 2; i <= cantidad_muestras_rssi + 1; i++)
    {
      if (braceletrssi[id][i] != 0)
      {
        promediorssi = promediorssi + braceletrssi[id][i];
        countvalpro++;
      }
      else
      {
        promediorssi = promediorssi / countvalpro;
        countvalpro = 0;
        //Serial.print("Promedio: ");
        //Serial.println(promediorssi);
        if (abs(data - promediorssi) <= intervalodifrssi)
        {
          braceletrssi[id][1] = data;
        }
        else
        {
          braceletrssi[id][1] = promediorssi;
        }
        break;
      }
    }
    if (countvalpro == cantidad_muestras_rssi)
    {
      promediorssi = promediorssi / cantidad_muestras_rssi;
      countvalpro = 0;
      //Serial.print("Promedio: ");
      //Serial.println(promediorssi);
      if (abs(data - promediorssi) <= intervalodifrssi)
      {
        braceletrssi[id][1] = data;
      }
      else
      {
        braceletrssi[id][1] = promediorssi;
      }
    }
  }
  else
  {
    braceletrssi[id][1] = data;
  }

  promediorssi = 0;
/*
  if (data != 0)
  {
    thisScan[id] = true;

    Serial.print("carrier (");
    Serial.print(id);
    Serial.print(") [");
    Serial.print(data);
    Serial.print("]: ");
    for (int i = 1; i < number_columns; i++)
    {
      Serial.print(braceletrssi[id][i]);
      Serial.print("-");
    }
    Serial.println();
  }
  */
}

bool BalizaHSBFCV::ValidRegistersVeryOld()
{
  for (int i = 0; i < number_rows; i++)
  {
    byte conteo_inactividad = 0;
    for (int j = 0; j < number_columns; j++)
    {
      if (estadoused[j] == true)
      {
        if (braceletrssi[i][j] == 0)
        {
          conteo_inactividad++;
          if (conteo_inactividad >= max_registers_no_used)
          {
            estadoused[i] = false;
            j = number_columns;
          }
        }
      }
    }
  }
}

void BalizaHSBFCV::MakeCarrierForBraceltsNotFindButYesRegister()
{
  for (int i = 0; i < number_rows; i++)
  {
    if (thisScan[i] == false)
    {
      int id = i;
      int new_data = 0;
      RegisterNewData(id, new_data);
    }
  }
}

void BalizaHSBFCV::loopScanear()
{
  //--------------------------------------
  if (d1 == 0)
  {
    Serial.println(" ");
    Serial.println("Iniciando Escaneo");
    HM10.println("AT+DISI?");
    Serial.println(" ");
    d1 = 1;
    i = 0;
  }
  //------------------------------------------
  if (d1 == 1)
  {
    if (HM10.available())
    {
      while (HM10.available())
      {
        disi_result[i] = char(HM10.read());
        //Serial.print(disi_result[i]);
        i++;
      }
    }
    String str = "";
    for (int j = i - 15; j <= i; j++)
    {
      str = str + disi_result[j];
    }
    if (str.indexOf("OK+DISCE") >= 0)
    {
      d1 = 2;
      //Serial.println(" ");
      //Serial.println("Escaneo Finalizado");
      //Serial.println(" ");
    }
    delay(50);
  }
  //-----------------------------------------
  if (d1 == 2)
  {
    int j = 0;
    String lineaEncontrada = "";
    DynamicJsonDocument beacons(1024);
    JsonArray data = beacons.createNestedArray("beacons");
    for (int i = 0; i < number_columns; i++)
    {
      thisScan[i] = false;
    }

    for (j = 0; j <= i; j++)
    {
      char c = disi_result[j];
      if (c != '\n')
      {
        lineaEncontrada = lineaEncontrada + c;
      }
      else
      {
        if (lineaEncontrada.indexOf("OK+DISC:0000") < 0)
        {
          //si si es beacon
          if (lineaEncontrada.indexOf("OK+DISC:4C000215:") >= 0)
          {
            lineaEncontrada.replace("OK+DISC:4C000215:", "");

            String fcv = lineaEncontrada.substring(4, 10);
            if (fcv.indexOf("706786") >= 0)
            {
              String macBeacon = lineaEncontrada.substring(10, 22);
              String mac_Beacon = lineaEncontrada.substring(44, 56);
              if (mac_Beacon.equals(macBeacon))
              {
                sedeBeacon = lineaEncontrada.substring(0, 4);
                voltajeBateria = lineaEncontrada.substring(22, 24);
                ppmBeacon = lineaEncontrada.substring(24, 27);
                proximidadBeacon = lineaEncontrada.substring(27, 28);
                caidaBeacon = lineaEncontrada.substring(28, 29);
                temperaturaBeacon = lineaEncontrada.substring(29, 32);
                rssiBeacon = lineaEncontrada.substring(58);
                rssiBeacon.replace("\r", "");

                int id = find_id_bracelet(mac_Beacon);
                RegisterNewData(id, rssiBeacon.toInt());
                rssiBeacon = braceletrssi[id][1];

                DynamicJsonDocument ibea = ProcesarDatos(sedeBeacon, voltajeBateria, ppmBeacon, proximidadBeacon, caidaBeacon, temperaturaBeacon, rssiBeacon, macBeacon);

                data.add(ibea);
              }
            }
          }
        }
        lineaEncontrada = "";
      }
    }
    MakeCarrierForBraceltsNotFindButYesRegister();
    ValidRegistersVeryOld();

    //------------------------------------------------------------------
    JsonArray data2 = beacons.createNestedArray("baliza");
    data2.add(macESP32);
    String output = "";
    serializeJson(beacons, output);
    //Serial.print("Datos Libreria A");
    //Serial.println(output);
    totalbeacons = output;
    d1 = 0;
    delay(1000);
  }
}
//****************************************************

String BalizaHSBFCV::Totalbeacons()
{
  return totalbeacons;
}



#endif