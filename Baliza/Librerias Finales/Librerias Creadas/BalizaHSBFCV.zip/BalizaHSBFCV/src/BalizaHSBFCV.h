#ifndef BalizaHSBFCV_h
#define BalizaHSBFCV_h

#include "Arduino.h"
#include <ArduinoJson.h>
#include <WiFi.h>

class BalizaHSBFCV
{

  public:
    void start_at();
    void loopScanear();
    String Totalbeacons();

    int find_id_bracelet(String mac_search);
    void RegisterNewData(int id, int data);
    bool ValidRegistersVeryOld();
    void MakeCarrierForBraceltsNotFindButYesRegister();

	private:

};

#endif
