<!-- START COMPATIBILITY TABLE -->

## Compatibility

MCU         |Tested Works|Doesn't Work|Not Tested|Notes
------------|:----------:|:----------:|:--------:|-----
ESP32		|      X     |            |          |


  * ESP32s 

<!-- END COMPATIBILITY TABLE -->