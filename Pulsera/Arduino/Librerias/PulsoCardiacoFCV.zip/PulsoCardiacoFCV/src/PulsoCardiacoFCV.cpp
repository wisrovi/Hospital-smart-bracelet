#include "Arduino.h"
#include "PulsoCardiacoFCV.h"
#include <Ticker.h>

int _pinSensorPPM;
int _pinVccSensorPPM;
#define _constanteLectura 15000 //Tiempo establecido para tomar la cantidad de pulsos.
int _conteoPulsos = 0;
int _pulsosAnterior = 0;
bool banderaControl = false;
boolean banderaPrimerPulso = false;
boolean cambioEstado = false;

void FinCheck();
void ReadPulso();

//Trae el valos de los pines de lectura y de voltaje del sensor ppm configurados en el codigo principal
PulsoCardiacoFCV::PulsoCardiacoFCV(int _pinSensor, int _pinVccSensor) {
  _pinSensorPPM = _pinSensor;
  _pinVccSensorPPM = _pinVccSensor;
  pinMode(_pinVccSensorPPM, OUTPUT);
}

Ticker CheckPulso(FinCheck, _constanteLectura);
Ticker LectorPulso(ReadPulso, 20);


//Entrega la cantidad final de pulsos
void FinCheck() {
  if (_conteoPulsos > 10) {
    _pulsosAnterior = _conteoPulsos;
  }
  _conteoPulsos = 0;

  banderaPrimerPulso = false;
  CheckPulso.stop();
  banderaControl = false;
}

//Establece el conteo de pulsos por cada secuencia de valoresaltos (1023) hasta el cambio a 0 cuenta un pulso.
void ReadPulso() {
  if (banderaControl) {
    int heartValue = analogRead(_pinSensorPPM);
    if (heartValue > 1000) {
      if ( !cambioEstado) {
        cambioEstado = true;
        _conteoPulsos++;
      }
      if (!banderaPrimerPulso) {
        banderaPrimerPulso = true;
        CheckPulso.start();
      }
    } else {
      cambioEstado = false;
    }
  }

}

//establece el pin de lectura y la cantidad de tiempo para tomar los pulsos.

void PulsoCardiacoFCV::StartSensorPPM() {
  digitalWrite(_pinVccSensorPPM, HIGH);
  delay(10);
  LectorPulso.start();
  banderaControl = true;
}

//Funcion para establecer los loop de los tickers creados.
void PulsoCardiacoFCV::LoopSensorPPM() {
  CheckPulso.update();
  LectorPulso.update();
}

//Funcion para detener los tickets y apagar el pin vcc del sensor.
void PulsoCardiacoFCV::StopSensorPPM() {
  CheckPulso.stop();
  LectorPulso.stop();
  digitalWrite(_pinVccSensorPPM, LOW);
}

//Funcion para retomar cuando se toma el primer pulso.
boolean PulsoCardiacoFCV::isBanderaPrimerPulso() {
  return banderaPrimerPulso;
}

//Funcion que calcula el valor ppm y lo envía al codigo principal.
int PulsoCardiacoFCV::ValorSPPM() {
  int producto = 60000 / _constanteLectura;
  return _pulsosAnterior * producto;
}
