<!-- START COMPATIBILITY TABLE -->

## Compatibility

MCU         |Tested Works|Doesn't Work|Not Tested|Notes
------------|:----------:|:----------:|:--------:|-----
Atmega328   |      X     |            |          |
Atmega328p  |      X     |            |          |


  * ATmega328p : Arduino UNO
  * ATmega328 : Arduino UNO

<!-- END COMPATIBILITY TABLE -->
