#ifndef SensorTemperaturaFCVDS18B20_h
#define SensorTemperaturaFCVDS18B20_h

#include <OneWire.h> //Se importan las librerías
#include <DallasTemperature.h>

class SensorTemperaturaFCVDS18B20

{
  public:
    SensorTemperaturaFCVDS18B20();
    float ValorTemperatura1820();
    void LoopSTemperatura1820();
    void StartSTemperatura1820();
	void SetupSTemperatura1820();
	void StopSTemperatura1820();

  private:

};

#endif