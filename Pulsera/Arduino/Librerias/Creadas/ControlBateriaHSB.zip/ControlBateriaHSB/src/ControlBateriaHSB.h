#ifndef ControlBateriaHSB_h
#define ControlBateriaHSB_h


 class ControlBateriaHSB
 
{
			
  public:
	void SetupSensoresHSB();
	void ControlSensoresHSB();
	      
  private:


};
  
#endif















