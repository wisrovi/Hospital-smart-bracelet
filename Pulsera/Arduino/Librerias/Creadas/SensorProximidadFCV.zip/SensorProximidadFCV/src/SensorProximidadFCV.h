#ifndef SensorProximidadFCV_h
#define SensorProximidadFCV_h

#include "Arduino.h"
#include <Ticker.h>

 class SensorProximidadFCV
 
{
			
  public:
  void StartSProximidad();
  void LoopSProximidad();
  boolean ValorProximidad();
  void StopSProximidad();
  void SetupSProximidad();
  
      
  private:
  
};
  
#endif















