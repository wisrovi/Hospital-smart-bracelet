<!-- START COMPATIBILITY TABLE -->

## Compatibility

MCU         |Tested Works|Doesn't Work|Not Tested|Notes
------------|:----------:|:----------:|:--------:|-----
Atmega328   |      X     |            |          |


  * ATmega328 : Arduino UNO

<!-- END COMPATIBILITY TABLE -->
